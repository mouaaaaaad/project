package com.java.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.java.api.dao.Biens;

@Service
public interface BiensRepository extends JpaRepository<Biens, Long> {

}
