package com.java.api.repository;

import javax.annotation.Resource;

import org.springframework.data.jpa.repository.JpaRepository;

import com.java.api.dao.Client;

@Resource
public interface ClientRepository extends JpaRepository<Client, Long> {

}
