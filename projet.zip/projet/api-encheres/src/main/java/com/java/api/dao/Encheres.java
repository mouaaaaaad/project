package com.java.api.dao;

import org.springframework.data.annotation.Id;

public class Encheres {

	@Id
	private Long id;
}
