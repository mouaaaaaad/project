package com.java.api.dao;

import org.springframework.data.annotation.Id;

public class Client {

	@Id
	private Long id;

}
