package com.java.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BiensController {

	@GetMapping("/Biens")
	public ResponseEntity<String> getBiens() {
//		encheresRepository.findById(1L);
//		return ResponseEntity.ok(encheresRepository.findById(1L));
		return ResponseEntity.ok("Service Biens Works");
	}
}
