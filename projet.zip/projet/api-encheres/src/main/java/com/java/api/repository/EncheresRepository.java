package com.java.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.java.api.dao.Encheres;

//@RepositoryRestResource
@Repository
public interface EncheresRepository extends JpaRepository<Encheres, Long> {

}
