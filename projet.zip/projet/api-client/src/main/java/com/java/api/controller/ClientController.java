package com.java.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientController {

	@GetMapping("/client")
	public ResponseEntity<String> getClient() {
//		encheresRepository.findById(1L);
//		return ResponseEntity.ok(encheresRepository.findById(1L));
		return ResponseEntity.ok("Service Client Works");
	}
}
